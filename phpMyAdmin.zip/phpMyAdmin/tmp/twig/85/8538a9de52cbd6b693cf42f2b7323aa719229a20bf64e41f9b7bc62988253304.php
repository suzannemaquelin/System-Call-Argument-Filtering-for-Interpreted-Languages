<?php

/* config/form_display/form_bottom.twig */
class __TwigTemplate_be63a18a447e1c268c8f6986a29539d7b88a241c53cb83c0fba1b8a79101ab49 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "</form>
";
    }

    public function getTemplateName()
    {
        return "config/form_display/form_bottom.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "config/form_display/form_bottom.twig", "/var/www/phpmyadmin/templates/config/form_display/form_bottom.twig");
    }
}
